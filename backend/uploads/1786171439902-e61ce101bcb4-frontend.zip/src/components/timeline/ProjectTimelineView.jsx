import { Link } from 'react-router-dom';
import { MapPin, Flag } from 'lucide-react';
import EmptyState from '../ui/EmptyState.jsx';
import Avatar from '../ui/Avatar.jsx';
import TiltCard from '../ui/TiltCard.jsx';
import { PROJECT_STATUS_META } from '../../config/statuses';
import { formatDate } from '../../utils/formatDate';
import { computeWindow, diffDays } from '../../utils/timelineScale';

const PRIORITY_BAR = {
  LOW: 'bg-ink-muted/40',
  MEDIUM: 'bg-route-500',
  HIGH: 'bg-accent-400',
  URGENT: 'bg-danger-400',
};

// Every project as a journey on one shared road — extended from the
// dashboard's original single-lane "active projects only" widget to
// show every project regardless of status, each on its own tilting
// card so the whole page has some depth to it.
export default function ProjectTimelineView({ projects = [], basePath = '/admin/projects', compact = false, className = '' }) {
  const withDates = projects.filter((p) => p.startDate && p.endDate);

  if (withDates.length === 0) {
    return (
      <EmptyState
        title="No projects on the road yet"
        description="Projects with a start and end date will appear here as a timeline."
      />
    );
  }

  const { rangeStart, rangeEnd } = computeWindow(
    withDates.map((p) => ({ startDate: p.startDate, dueDate: p.endDate }))
  );
  const totalSpan = diffDays(rangeEnd, rangeStart);
  const now = new Date();
  const todayPct = now >= rangeStart && now <= rangeEnd ? (diffDays(now, rangeStart) / totalSpan) * 100 : null;

  const list = compact ? withDates.slice(0, 5) : withDates;

  return (
    <div className={`flex flex-col gap-3 ${className}`}>
      {!compact && (
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-ink-muted">
          <div className="flex items-center gap-3">
            {Object.entries(PRIORITY_BAR).map(([priority, cls]) => (
              <span key={priority} className="flex items-center gap-1.5">
                <span className={`h-1.5 w-1.5 rounded-full ${cls}`} />
                {priority[0] + priority.slice(1).toLowerCase()}
              </span>
            ))}
          </div>
          <span className="font-mono">
            {formatDate(rangeStart)} — {formatDate(rangeEnd)}
          </span>
        </div>
      )}

      <div className={`flex flex-1 flex-col gap-3 ${compact ? 'justify-between' : ''}`}>
        {list.map((project) => {
          const start = new Date(project.startDate);
          const end = new Date(project.endDate);
          const left = (diffDays(start, rangeStart) / totalSpan) * 100;
          const width = Math.max((diffDays(end, start) / totalSpan) * 100, 3);
          const statusMeta = PROJECT_STATUS_META[project.status];

          return (
            <TiltCard key={project.id} maxTilt={3} className={`rounded-lg ${compact ? 'flex-1' : ''}`}>
              <Link
                to={`${basePath}/${project.id}`}
                className="group flex h-full flex-col justify-center rounded-lg border border-line bg-surface px-4 py-3 shadow-card transition-all duration-200 hover:-translate-y-0.5 hover:shadow-pop"
              >
                <div className="mb-3 flex items-center justify-between gap-2">
                  <div className="flex min-w-0 items-center gap-2">
                    <span className="truncate text-sm font-medium text-ink group-hover:text-route-600">
                      {project.name}
                    </span>
                    {statusMeta && (
                      <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-medium ${statusMeta.className}`}>
                        {statusMeta.label}
                      </span>
                    )}
                  </div>
                  <div className="flex shrink-0 items-center gap-2 text-xs text-ink-muted">
                    {project.manager && <Avatar name={project.manager.name} size="sm" />}
                    <span className="hidden sm:inline">
                      {formatDate(project.startDate)} – {formatDate(project.endDate)}
                    </span>
                  </div>
                </div>

                <div className="route-line relative h-px w-full">
                  {todayPct != null && (
                    <div
                      className="absolute -top-3 h-[22px] w-px bg-accent-500/70"
                      style={{ left: `${todayPct}%` }}
                      title="Today"
                    />
                  )}
                  <div
                    className="absolute -top-[6px] flex items-center transition-transform group-hover:-translate-y-0.5"
                    style={{ left: `${left}%`, width: `${width}%` }}
                  >
                    <MapPin className="h-3 w-3 shrink-0 -translate-x-1 text-ink-soft" />
                    <span
                      className={`h-2 flex-1 rounded-full shadow-sm ${PRIORITY_BAR[project.priority] || 'bg-route-500'}`}
                    />
                    <Flag className="h-3 w-3 shrink-0 translate-x-1 text-ink-soft" />
                  </div>
                </div>
              </Link>
            </TiltCard>
          );
        })}
      </div>

      {compact && withDates.length > 5 && (
        <p className="pt-1 text-center text-xs text-ink-muted">+{withDates.length - 5} more on the full timeline</p>
      )}
    </div>
  );
}
