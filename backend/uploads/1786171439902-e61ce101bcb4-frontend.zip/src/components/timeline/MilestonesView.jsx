import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Flag, Diamond } from 'lucide-react';
import clsx from 'clsx';
import EmptyState from '../ui/EmptyState.jsx';
import TiltCard from '../ui/TiltCard.jsx';
import { computeWindow, diffDays, formatShort, formatMonthYear } from '../../utils/timelineScale';

// Milestones = project end dates + tasks explicitly flagged isMilestone.
// Laid out as flags along one horizontal axis, grouped by month, each
// on a tilting card for the same premium depth as the rest of the page.
export default function MilestonesView({ tasks = [], projects = [], basePath = '/admin/tasks' }) {
  const items = useMemo(() => {
    const fromTasks = tasks
      .filter((t) => t.isMilestone && t.dueDate)
      .map((t) => ({ id: t.id, kind: 'task', title: t.title, date: new Date(t.dueDate), project: t.project }));
    const fromProjects = projects
      .filter((p) => p.endDate)
      .map((p) => ({ id: p.id, kind: 'project', title: `${p.name} — deadline`, date: new Date(p.endDate), project: p }));
    return [...fromTasks, ...fromProjects].sort((a, b) => a.date - b.date);
  }, [tasks, projects]);

  if (items.length === 0) {
    return (
      <EmptyState
        title="No milestones yet"
        description="Mark a task as a milestone, or set a project deadline, and it'll show up here."
      />
    );
  }

  const { rangeStart, rangeEnd } = computeWindow(items.map((i) => ({ dueDate: i.date })));
  const totalSpan = Math.max(diffDays(rangeEnd, rangeStart), 1);
  const now = new Date();
  const todayPct = now >= rangeStart && now <= rangeEnd ? (diffDays(now, rangeStart) / totalSpan) * 100 : null;

  let lastMonth = null;

  return (
    <div className="flex flex-col gap-4">
      {/* Axis */}
      <div className="route-line relative mx-2 h-px">
        {todayPct != null && (
          <div className="absolute -top-2 h-4 w-px bg-accent-500/70" style={{ left: `${todayPct}%` }} title="Today" />
        )}
        {items.map((item) => {
          const pct = (diffDays(item.date, rangeStart) / totalSpan) * 100;
          return (
            <div
              key={`${item.kind}-${item.id}`}
              className="group absolute -top-1.5 flex flex-col items-center"
              style={{ left: `${pct}%` }}
            >
              {item.kind === 'project' ? (
                <Flag className="h-3 w-3 text-route-600" />
              ) : (
                <Diamond className="h-2.5 w-2.5 fill-accent-400 text-accent-600" />
              )}
            </div>
          );
        })}
      </div>

      {/* List, grouped by month */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((item) => {
          const monthKey = formatMonthYear(item.date);
          const showMonthLabel = monthKey !== lastMonth;
          lastMonth = monthKey;

          const card = (
            <TiltCard maxTilt={4} className="h-full rounded-lg">
              <Link
                to={item.kind === 'task' ? `${basePath}/${item.id}` : `/admin/projects/${item.id}`}
                className="flex h-full flex-col gap-2 rounded-lg border border-line bg-surface p-4 shadow-card transition-shadow hover:shadow-pop"
              >
                <div className="flex items-center gap-2">
                  <span
                    className={clsx(
                      'flex h-7 w-7 shrink-0 items-center justify-center rounded-lg',
                      item.kind === 'project' ? 'bg-route-100 text-route-600' : 'bg-accent-100 text-accent-600'
                    )}
                  >
                    {item.kind === 'project' ? <Flag className="h-3.5 w-3.5" /> : <Diamond className="h-3.5 w-3.5" />}
                  </span>
                  <span className="font-mono text-xs text-ink-muted">{formatShort(item.date)}</span>
                </div>
                <p className="text-sm font-medium text-ink">{item.title}</p>
                {item.project?.name && item.kind === 'task' && (
                  <p className="text-xs text-ink-muted">{item.project.name}</p>
                )}
              </Link>
            </TiltCard>
          );

          return (
            <div key={`${item.kind}-${item.id}-card`} className="flex flex-col gap-2">
              {showMonthLabel && (
                <p className="text-[11px] font-semibold uppercase tracking-wide text-ink-muted">{monthKey}</p>
              )}
              {card}
            </div>
          );
        })}
      </div>
    </div>
  );
}
