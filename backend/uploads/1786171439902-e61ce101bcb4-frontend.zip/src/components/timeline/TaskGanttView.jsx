import { useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Diamond } from 'lucide-react';
import clsx from 'clsx';
import EmptyState from '../ui/EmptyState.jsx';
import Avatar from '../ui/Avatar.jsx';
import { PRIORITY_META } from '../../config/statuses';
import {
  DAY,
  ZOOM_LEVELS,
  addDays,
  computeWindow,
  diffDays,
  effectiveRange,
  formatShort,
  startOfDay,
} from '../../utils/timelineScale';

const ROW_HEIGHT = 40;
const LABEL_WIDTH = 240;

function buildTicks(rangeStart, rangeEnd, unit) {
  const ticks = [];
  let cursor = startOfDay(rangeStart);
  const end = startOfDay(rangeEnd);
  while (cursor <= end) {
    ticks.push(new Date(cursor));
    if (unit === 'day') cursor = addDays(cursor, 1);
    else if (unit === 'week') cursor = addDays(cursor, 7);
    else cursor = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1);
  }
  return ticks;
}

// Task-level Gantt: bars grouped by project, dependency connectors drawn
// as elbowed SVG paths, milestones rendered as diamonds, bars draggable
// (horizontal move = reschedule keeping duration, edge drag = resize).
export default function TaskGanttView({ tasks = [], zoom, basePath = '/admin/tasks', onReschedule }) {
  const scrollRef = useRef(null);
  const [dragState, setDragState] = useState(null); // { taskId, mode, startX, originalStart, originalDue }
  const [localOverrides, setLocalOverrides] = useState({});

  const { pxPerDay, tickUnit } = ZOOM_LEVELS[zoom];

  const effective = tasks.map((t) => ({ ...t, ...localOverrides[t.id] }));

  const { rangeStart, rangeEnd } = useMemo(() => computeWindow(effective), [effective]);
  const totalDays = Math.max(diffDays(rangeEnd, rangeStart), 1);
  const totalWidth = totalDays * pxPerDay;
  const ticks = useMemo(() => buildTicks(rangeStart, rangeEnd, tickUnit), [rangeStart, rangeEnd, tickUnit]);

  const dateToX = (date) => diffDays(date, rangeStart) * pxPerDay;

  // Group tasks by project so the chart reads as swimlanes, and assign
  // each visible row (group header + task) a sequential index for the
  // pixel Y math the dependency connectors rely on.
  const groups = useMemo(() => {
    const byProject = new Map();
    effective.forEach((t) => {
      const key = t.project?.id || 'unassigned';
      if (!byProject.has(key)) byProject.set(key, { project: t.project, tasks: [] });
      byProject.get(key).tasks.push(t);
    });
    return [...byProject.values()];
  }, [effective]);

  const rows = []; // { type: 'header'|'task', task?, project? }
  groups.forEach((g) => {
    rows.push({ type: 'header', project: g.project });
    g.tasks.forEach((task) => rows.push({ type: 'task', task }));
  });
  const rowIndexByTaskId = new Map(rows.map((r, i) => [r.task?.id, i]).filter(([id]) => id));

  const now = new Date();
  const todayX = now >= rangeStart && now <= rangeEnd ? dateToX(now) : null;

  function handlePointerDown(e, task, mode) {
    e.preventDefault();
    e.stopPropagation();
    const { start } = effectiveRange(task);
    setDragState({
      taskId: task.id,
      mode, // 'move' | 'resize-end'
      startClientX: e.clientX,
      originalStart: start,
      originalDue: new Date(task.dueDate),
    });

    function handleMove(ev) {
      setDragState((prev) => {
        if (!prev) return prev;
        const deltaPx = ev.clientX - prev.startClientX;
        const deltaDays = Math.round(deltaPx / pxPerDay);
        let newStart = prev.originalStart;
        let newDue = prev.originalDue;
        if (prev.mode === 'move') {
          newStart = addDays(prev.originalStart, deltaDays);
          newDue = addDays(prev.originalDue, deltaDays);
        } else {
          newDue = addDays(prev.originalDue, deltaDays);
          if (newDue < prev.originalStart) newDue = prev.originalStart;
        }
        setLocalOverrides((o) => ({
          ...o,
          [prev.taskId]: { startDate: newStart.toISOString(), dueDate: newDue.toISOString() },
        }));
        return prev;
      });
    }

    function handleUp() {
      window.removeEventListener('pointermove', handleMove);
      window.removeEventListener('pointerup', handleUp);
      setDragState((prev) => {
        if (prev) {
          const override = localOverrides[prev.taskId];
          if (override && onReschedule) {
            onReschedule(prev.taskId, override).catch(() => {
              setLocalOverrides((o) => {
                const next = { ...o };
                delete next[prev.taskId];
                return next;
              });
            });
          }
        }
        return null;
      });
    }

    window.addEventListener('pointermove', handleMove);
    window.addEventListener('pointerup', handleUp);
  }

  if (tasks.length === 0) {
    return (
      <EmptyState
        title="No scheduled tasks yet"
        description="Tasks with a due date will appear here as Gantt bars. Add a start date for a full-width bar."
      />
    );
  }

  return (
    <div className="overflow-hidden rounded-lg border border-line bg-surface">
      <div className="flex">
        {/* Fixed label column */}
        <div className="shrink-0 border-r border-line" style={{ width: LABEL_WIDTH }}>
          <div className="flex items-center border-b border-line px-3 text-[11px] font-semibold uppercase tracking-wide text-ink-muted" style={{ height: 36 }}>
            Task
          </div>
          {rows.map((row, i) =>
            row.type === 'header' ? (
              <div
                key={`h-${i}`}
                className="flex items-center bg-paper/70 px-3 text-xs font-semibold text-ink-soft"
                style={{ height: ROW_HEIGHT }}
              >
                {row.project?.name || 'Unassigned'}
              </div>
            ) : (
              <Link
                key={row.task.id}
                to={`${basePath}/${row.task.id}`}
                className="flex items-center gap-2 truncate px-3 text-sm text-ink hover:text-route-600"
                style={{ height: ROW_HEIGHT }}
                title={row.task.title}
              >
                {row.task.isMilestone && <Diamond className="h-3 w-3 shrink-0 text-accent-500" />}
                <span className="truncate">{row.task.title}</span>
              </Link>
            )
          )}
        </div>

        {/* Scrollable timeline area */}
        <div ref={scrollRef} className="relative flex-1 overflow-x-auto">
          <div style={{ width: totalWidth, minWidth: '100%' }}>
            {/* Ruler */}
            <div className="relative border-b border-line" style={{ height: 36 }}>
              {ticks.map((tick, i) => (
                <div
                  key={i}
                  className="absolute top-0 h-full border-l border-line/70 pl-1.5 text-[10px] font-medium text-ink-muted"
                  style={{ left: dateToX(tick) }}
                >
                  <span className="leading-9">
                    {tickUnit === 'month'
                      ? tick.toLocaleDateString(undefined, { month: 'short', year: '2-digit' })
                      : formatShort(tick)}
                  </span>
                </div>
              ))}
            </div>

            {/* Rows + bars */}
            <div className="relative" style={{ height: rows.length * ROW_HEIGHT }}>
              {/* Today marker */}
              {todayX != null && (
                <div
                  className="absolute top-0 z-10 w-px bg-accent-500/70"
                  style={{ left: todayX, height: rows.length * ROW_HEIGHT }}
                >
                  <span className="absolute -top-0 left-1 whitespace-nowrap rounded bg-accent-500 px-1 py-0.5 text-[9px] font-semibold text-white">
                    Today
                  </span>
                </div>
              )}

              {/* Row backgrounds */}
              {rows.map((row, i) => (
                <div
                  key={i}
                  className={clsx('absolute left-0 right-0 border-b border-line/60', row.type === 'header' && 'bg-paper/70')}
                  style={{ top: i * ROW_HEIGHT, height: ROW_HEIGHT }}
                />
              ))}

              {/* Dependency connectors */}
              <svg
                className="pointer-events-none absolute left-0 top-0"
                width={totalWidth}
                height={rows.length * ROW_HEIGHT}
              >
                {rows.map((row) => {
                  if (row.type !== 'task' || !row.task.dependsOn?.length) return null;
                  const toIndex = rowIndexByTaskId.get(row.task.id);
                  const { start: toStart } = effectiveRange(row.task);
                  const toX = dateToX(toStart);
                  const toY = toIndex * ROW_HEIGHT + ROW_HEIGHT / 2;

                  return row.task.dependsOn.map((dep) => {
                    const fromIndex = rowIndexByTaskId.get(dep.id);
                    if (fromIndex == null) return null;
                    const fromTask = effective.find((t) => t.id === dep.id);
                    if (!fromTask) return null;
                    const { end: fromEnd } = effectiveRange(fromTask);
                    const fromX = dateToX(fromEnd);
                    const fromY = fromIndex * ROW_HEIGHT + ROW_HEIGHT / 2;
                    const midX = fromX + Math.max((toX - fromX) / 2, 12);

                    return (
                      <path
                        key={`${dep.id}-${row.task.id}`}
                        d={`M ${fromX} ${fromY} H ${midX} V ${toY} H ${toX}`}
                        fill="none"
                        stroke="#7FADD1"
                        strokeWidth="1.5"
                        strokeDasharray="3 3"
                        markerEnd="url(#gantt-arrow)"
                      />
                    );
                  });
                })}
                <defs>
                  <marker id="gantt-arrow" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                    <path d="M0,0 L6,3 L0,6 Z" fill="#7FADD1" />
                  </marker>
                </defs>
              </svg>

              {/* Bars */}
              {rows.map((row, i) => {
                if (row.type !== 'task') return null;
                const task = row.task;
                const { start, end } = effectiveRange(task);
                const left = dateToX(start);
                const width = Math.max(diffDays(end, start) * pxPerDay, 6);
                const priorityMeta = PRIORITY_META[task.priority];
                const isDragging = dragState?.taskId === task.id;

                if (task.isMilestone) {
                  return (
                    <div
                      key={task.id}
                      className="absolute flex items-center justify-center"
                      style={{ left: left - 7, top: i * ROW_HEIGHT + ROW_HEIGHT / 2 - 7, width: 14, height: 14 }}
                      title={`${task.title} — ${formatShort(end)}`}
                    >
                      <Diamond className="h-3.5 w-3.5 fill-accent-400 text-accent-600" />
                    </div>
                  );
                }

                return (
                  <div
                    key={task.id}
                    className={clsx(
                      'group absolute flex cursor-grab items-center overflow-hidden rounded-md border shadow-sm transition-shadow active:cursor-grabbing',
                      isDragging ? 'z-20 shadow-pop ring-2 ring-route-400' : 'hover:shadow-pop',
                      task.status === 'COMPLETED' ? 'border-success-400/50 bg-success-50' : 'border-route-400/50 bg-route-50'
                    )}
                    style={{ left, width, top: i * ROW_HEIGHT + 6, height: ROW_HEIGHT - 12 }}
                    onPointerDown={(e) => handlePointerDown(e, task, 'move')}
                    title={`${task.title} · ${formatShort(start)} – ${formatShort(end)}`}
                  >
                    <div
                      className={clsx(
                        'absolute inset-y-0 left-0 rounded-l-md',
                        task.status === 'COMPLETED' ? 'bg-success-400/40' : 'bg-route-400/40'
                      )}
                      style={{ width: `${Math.min(Math.max(task.progress || 0, 0), 100)}%` }}
                    />
                    <span className="relative z-10 truncate px-2 text-[11px] font-medium text-ink">
                      {task.assignee && <Avatar name={task.assignee.name} size="sm" className="mr-1 inline-flex h-4 w-4 align-middle text-[8px]" />}
                      {task.title}
                    </span>
                    {priorityMeta && (
                      <span
                        className="absolute right-1 top-1/2 h-1.5 w-1.5 -translate-y-1/2 rounded-full"
                        style={{ background: task.priority === 'URGENT' ? '#F0324B' : task.priority === 'HIGH' ? '#FF8C1A' : '#5B4FE0' }}
                      />
                    )}
                    {/* Resize handle */}
                    <div
                      className="absolute right-0 top-0 h-full w-2 cursor-ew-resize opacity-0 group-hover:opacity-100"
                      onPointerDown={(e) => handlePointerDown(e, task, 'resize-end')}
                    >
                      <div className="mx-auto mt-1 h-[calc(100%-8px)] w-0.5 rounded-full bg-route-600/60" />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
