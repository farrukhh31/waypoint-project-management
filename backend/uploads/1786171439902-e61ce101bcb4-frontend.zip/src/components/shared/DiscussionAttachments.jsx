import { FileText, Link2, Download } from 'lucide-react';

function formatSize(bytes) {
  if (!bytes && bytes !== 0) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// Renders the files/links carried by a discussion entry (a submission, a
// review decision, or a regular comment). Nothing renders if the entry has
// neither — most comments won't.
export default function DiscussionAttachments({ attachments = [], links = [] }) {
  if (attachments.length === 0 && links.length === 0) return null;

  return (
    <div className="mt-2 flex flex-col gap-1.5">
      {attachments.map((a, i) => (
        <a
          key={`${a.url}-${i}`}
          href={a.url}
          target="_blank"
          rel="noreferrer"
          className="inline-flex w-fit items-center gap-2 rounded border border-line bg-paper px-2.5 py-1.5 text-xs text-ink-soft transition-colors hover:border-route-300 hover:bg-route-50/50 hover:text-route-700"
        >
          <FileText className="h-3.5 w-3.5 shrink-0 text-ink-muted" />
          <span className="max-w-[220px] truncate">{a.name}</span>
          {a.size != null && <span className="shrink-0 text-ink-muted">{formatSize(a.size)}</span>}
          <Download className="h-3 w-3 shrink-0 text-ink-muted" />
        </a>
      ))}
      {links.map((l, i) => (
        <a
          key={`${l.url}-${i}`}
          href={l.url}
          target="_blank"
          rel="noreferrer"
          className="inline-flex w-fit items-center gap-2 rounded border border-line bg-paper px-2.5 py-1.5 text-xs text-route-600 transition-colors hover:border-route-300 hover:bg-route-50/50"
        >
          <Link2 className="h-3.5 w-3.5 shrink-0" />
          <span className="max-w-[220px] truncate">{l.label}</span>
        </a>
      ))}
    </div>
  );
}
