import { useRef, useState } from 'react';
import { Paperclip, Link2, X, Loader2, FileText } from 'lucide-react';
import api from '../../lib/api';
import Button from '../ui/Button.jsx';
import Input from '../ui/Input.jsx';

function formatSize(bytes) {
  if (!bytes && bytes !== 0) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// Lets a submission (or a comment) carry structured deliverables — actual
// uploaded files, plus links to things that live elsewhere (a repo, a
// staging URL, a Drive folder). Files are uploaded immediately on
// selection via POST /api/uploads; the parent only ever holds back the
// resulting { name, url, size, mimeType } metadata, same shape the
// backend stores on the discussion entry.
export default function AttachmentsLinksPicker({ attachments, onAttachmentsChange, links, onLinksChange }) {
  const fileInputRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [linkDraft, setLinkDraft] = useState({ label: '', url: '' });
  const [error, setError] = useState('');

  async function handleFilesSelected(e) {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;
    setError('');
    setUploading(true);
    try {
      const formData = new FormData();
      files.forEach((f) => formData.append('files', f));
      const { data } = await api.post('/uploads', formData);
      onAttachmentsChange([...attachments, ...data.data.files]);
    } catch (err) {
      setError(err.response?.data?.message || 'Could not upload one or more files.');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  }

  function removeAttachment(index) {
    onAttachmentsChange(attachments.filter((_, i) => i !== index));
  }

  function addLink() {
    if (!linkDraft.url.trim()) return;
    let url = linkDraft.url.trim();
    if (!/^https?:\/\//i.test(url)) url = `https://${url}`;
    onLinksChange([...links, { label: linkDraft.label.trim() || url, url }]);
    setLinkDraft({ label: '', url: '' });
  }

  function removeLink(index) {
    onLinksChange(links.filter((_, i) => i !== index));
  }

  return (
    <div className="flex flex-col gap-3">
      {/* Uploaded files */}
      {attachments.length > 0 && (
        <ul className="flex flex-col gap-1.5">
          {attachments.map((a, i) => (
            <li
              key={`${a.url}-${i}`}
              className="flex items-center gap-2 rounded border border-line bg-paper px-2.5 py-1.5 text-xs"
            >
              <FileText className="h-3.5 w-3.5 shrink-0 text-ink-muted" />
              <span className="min-w-0 flex-1 truncate text-ink-soft">{a.name}</span>
              {a.size != null && <span className="shrink-0 text-ink-muted">{formatSize(a.size)}</span>}
              <button
                type="button"
                onClick={() => removeAttachment(i)}
                className="shrink-0 rounded p-0.5 text-ink-muted hover:bg-line/60 hover:text-danger-600"
                aria-label={`Remove ${a.name}`}
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </li>
          ))}
        </ul>
      )}

      {/* Links */}
      {links.length > 0 && (
        <ul className="flex flex-col gap-1.5">
          {links.map((l, i) => (
            <li
              key={`${l.url}-${i}`}
              className="flex items-center gap-2 rounded border border-line bg-paper px-2.5 py-1.5 text-xs"
            >
              <Link2 className="h-3.5 w-3.5 shrink-0 text-ink-muted" />
              <span className="min-w-0 flex-1 truncate text-route-600">{l.label}</span>
              <button
                type="button"
                onClick={() => removeLink(i)}
                className="shrink-0 rounded p-0.5 text-ink-muted hover:bg-line/60 hover:text-danger-600"
                aria-label={`Remove ${l.label}`}
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </li>
          ))}
        </ul>
      )}

      {/* Add a link */}
      <div className="flex items-center gap-1.5">
        <Input
          value={linkDraft.label}
          onChange={(e) => setLinkDraft({ ...linkDraft, label: e.target.value })}
          placeholder="Label (optional)"
          className="!h-9 w-32 shrink-0 text-xs"
        />
        <Input
          value={linkDraft.url}
          onChange={(e) => setLinkDraft({ ...linkDraft, url: e.target.value })}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              addLink();
            }
          }}
          placeholder="https://…  (repo, drive, staging link)"
          className="!h-9 flex-1 text-xs"
        />
        <Button type="button" size="sm" variant="secondary" onClick={addLink} disabled={!linkDraft.url.trim()}>
          <Link2 className="h-3.5 w-3.5" /> Add
        </Button>
      </div>

      {/* Add files */}
      <div className="flex items-center gap-2">
        <input ref={fileInputRef} type="file" multiple className="hidden" onChange={handleFilesSelected} />
        <Button
          type="button"
          size="sm"
          variant="secondary"
          disabled={uploading}
          onClick={() => fileInputRef.current?.click()}
        >
          {uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Paperclip className="h-3.5 w-3.5" />}
          {uploading ? 'Uploading…' : 'Attach files'}
        </Button>
        <span className="text-xs text-ink-muted">Up to 25MB each</span>
      </div>

      {error && <p className="text-xs text-danger-600">{error}</p>}
    </div>
  );
}
