import { Link } from 'react-router-dom';
import clsx from 'clsx';
import Badge from '../ui/Badge.jsx';
import Avatar from '../ui/Avatar.jsx';
import { TASK_STATUS_META, PRIORITY_META } from '../../config/statuses';
import { formatDueDate } from '../../utils/formatDate';

const STATUS_DOT = {
  TODO: 'bg-ink-muted',
  IN_PROGRESS: 'bg-route-500',
  REVIEW: 'bg-accent-400',
  COMPLETED: 'bg-success-400',
};

export default function TaskRow({ task, basePath, showAssignee = true }) {
  const dueLabel = formatDueDate(task.dueDate);
  const isOverdue = dueLabel.includes('overdue') && task.status !== 'COMPLETED';

  return (
    <Link
      to={`${basePath}/${task.id}`}
      className="group flex items-center gap-4 px-5 py-3.5 transition-all duration-150 hover:translate-x-0.5 hover:bg-paper"
    >
      <span className={clsx('h-2 w-2 shrink-0 rounded-full', STATUS_DOT[task.status])} aria-hidden="true" />
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium text-ink transition-colors group-hover:text-route-700">
          {task.title}
        </p>
        <p className="truncate text-xs text-ink-muted">{task.project?.name}</p>
      </div>
      {showAssignee && <Avatar name={task.assignee?.name} size="sm" />}
      <Badge meta={PRIORITY_META[task.priority]} />
      <Badge meta={TASK_STATUS_META[task.status]} />
      <span className={clsx('w-24 shrink-0 text-right text-xs', isOverdue ? 'font-medium text-danger-600' : 'text-ink-muted')}>
        {dueLabel}
      </span>
    </Link>
  );
}
