import { useState } from 'react';
import Modal from '../ui/Modal.jsx';
import Button from '../ui/Button.jsx';
import { Textarea, Field } from '../ui/Input.jsx';
import AttachmentsLinksPicker from './AttachmentsLinksPicker.jsx';

// Used for both "Submit for review" (task) and "Submit for approval"
// (project) — the deliverable is the same shape either way: a note plus
// whatever files/links prove the work is done.
export default function SubmissionModal({ open, onClose, title, subtitle, submitLabel = 'Submit', onSubmit }) {
  const [comment, setComment] = useState('');
  const [attachments, setAttachments] = useState([]);
  const [links, setLinks] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  function reset() {
    setComment('');
    setAttachments([]);
    setLinks([]);
    setError('');
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      await onSubmit({ comment: comment.trim() || undefined, attachments, links });
      reset();
      onClose();
    } catch (err) {
      setError(err.response?.data?.message || 'Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={() => {
        reset();
        onClose();
      }}
      title={title}
    >
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        {subtitle && <p className="text-sm text-ink-muted">{subtitle}</p>}

        <Field label="Notes (optional)" htmlFor="submission-comment">
          <Textarea
            id="submission-comment"
            rows={3}
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Anything the reviewer should know…"
          />
        </Field>

        <Field label="Files & links">
          <AttachmentsLinksPicker
            attachments={attachments}
            onAttachmentsChange={setAttachments}
            links={links}
            onLinksChange={setLinks}
          />
        </Field>

        {error && <p className="text-sm text-danger-600">{error}</p>}

        <div className="flex justify-end gap-2 border-t border-line pt-4">
          <Button type="button" variant="secondary" disabled={submitting} onClick={() => { reset(); onClose(); }}>
            Cancel
          </Button>
          <Button type="submit" loading={submitting}>
            {submitLabel}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
