import { Link } from 'react-router-dom';
import { FolderPlus, Pencil, UserPlus, UserMinus, ListPlus, ListTodo, GitCommitHorizontal } from 'lucide-react';
import Card, { CardHeader, CardBody } from '../ui/Card.jsx';
import Avatar from '../ui/Avatar.jsx';
import EmptyState from '../ui/EmptyState.jsx';
import ActivityPillChart from './ActivityPillChart.jsx';
import { formatDate } from '../../utils/formatDate';

const ACTION_LABELS = {
  project_created: 'created the project',
  project_updated: 'updated the project details',
  members_added: 'added team members',
  member_removed: 'removed a team member',
  task_created: 'created a task',
  task_updated: 'updated a task',
  discussion_added: 'posted a discussion comment',
};

// Icon + accent color per action, pulled from the same status palette
// used everywhere else (route = in motion, accent = attention, success
// = done, danger = removed) so this reads as one language with the
// status badges and the timeline widget rather than a new color set.
const ACTION_STYLE = {
  project_created: { icon: FolderPlus, ring: 'ring-route-200 bg-route-50 text-route-600' },
  project_updated: { icon: Pencil, ring: 'ring-route-200 bg-route-50 text-route-600' },
  members_added: { icon: UserPlus, ring: 'ring-success-50 bg-success-50 text-success-600' },
  member_removed: { icon: UserMinus, ring: 'ring-danger-50 bg-danger-50 text-danger-600' },
  task_created: { icon: ListPlus, ring: 'ring-accent-100 bg-accent-50 text-accent-600' },
  task_updated: { icon: ListTodo, ring: 'ring-accent-100 bg-accent-50 text-accent-600' },
  discussion_added: { icon: GitCommitHorizontal, ring: 'ring-route-200 bg-route-50 text-route-600' },
};

function describe(log) {
  return ACTION_LABELS[log.action] || log.action.replace(/_/g, ' ');
}

export default function ActivityFeed({ logs = [], activityByDay = [] }) {
  return (
    <Card className="overflow-hidden transition-shadow duration-200 hover:shadow-pop">
      <CardHeader className="bg-gradient-to-r from-route-50/60 via-surface to-surface">
        <h3 className="font-display text-base font-semibold text-ink">Recent activity</h3>
        <span className="text-xs text-ink-muted">Last 7 days</span>
      </CardHeader>
      <CardBody className="flex flex-col gap-5">
        {activityByDay.length > 0 && (
          <div className="rounded-lg border border-line bg-paper/40 p-4">
            <ActivityPillChart days={activityByDay} />
            <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1.5 border-t border-line pt-3 text-[11px] text-ink-muted">
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-route-400" /> Project activity
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-accent-400" /> Task activity
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-success-400" /> Team activity
              </span>
            </div>
          </div>
        )}

        <div>
          <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-ink-muted">Last actions</p>
          {logs.length === 0 ? (
            <EmptyState title="Quiet so far" description="Project and task activity will show up here." />
          ) : (
          <ul className="relative flex flex-col gap-5">
            {/* Shared connector line running down the icon column */}
            <div className="route-line-v absolute bottom-2 left-[15px] top-2 w-px" aria-hidden="true" />
            {logs.map((log) => {
              const style = ACTION_STYLE[log.action] || {
                icon: GitCommitHorizontal,
                ring: 'ring-ink-muted/20 bg-paper text-ink-muted',
              };
              const Icon = style.icon;
              return (
                <li key={log.id} className="group relative flex items-start gap-3 pl-0">
                  <span
                    className={`relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full ring-4 ring-offset-0 shadow-sm transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:shadow-card ${style.ring}`}
                  >
                    <Icon className="h-3.5 w-3.5" />
                  </span>
                  <div className="flex min-w-0 flex-1 items-start justify-between gap-3 rounded-lg px-2 py-1 transition-colors duration-150 group-hover:bg-paper">
                    <div className="min-w-0">
                      <p className="text-sm text-ink-soft">
                        <span className="font-medium text-ink">{log.actor?.name ?? 'Someone'}</span>{' '}
                        {describe(log)}
                        {log.Project?.name && (
                          <>
                            {' '}
                            in{' '}
                            <Link to={`/admin/projects/${log.Project.id}`} className="font-medium text-route-600 hover:underline">
                              {log.Project.name}
                            </Link>
                          </>
                        )}
                      </p>
                      <p className="mt-0.5 text-xs text-ink-muted">{formatDate(log.createdAt)}</p>
                    </div>
                    <Avatar name={log.actor?.name} size="sm" className="shrink-0 shadow-sm" />
                  </div>
                </li>
              );
            })}
          </ul>
          )}
        </div>
      </CardBody>
    </Card>
  );
}
