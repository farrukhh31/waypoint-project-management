import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Plus, Pencil, Trash2, MailPlus } from 'lucide-react';
import api from '../../lib/api';
import { useAuth } from '../../hooks/useAuth';
import { useList } from '../../hooks/useList';
import { ROLE_LABELS } from '../../config/roles';
import PageHeader from '../../components/shared/PageHeader.jsx';
import { Toolbar, SearchField, Select } from '../../components/shared/Toolbar.jsx';
import PendingInvites from '../../components/shared/PendingInvites.jsx';
import Card from '../../components/ui/Card.jsx';
import Avatar from '../../components/ui/Avatar.jsx';
import Button from '../../components/ui/Button.jsx';
import EmptyState from '../../components/ui/EmptyState.jsx';
import Pagination from '../../components/ui/Pagination.jsx';
import UserForm from '../../components/forms/UserForm.jsx';
import InviteForm from '../../components/forms/InviteForm.jsx';

export default function Users() {
  const { user: currentUser } = useAuth();
  const [search, setSearch] = useState('');
  const [role, setRole] = useState('');
  const [page, setPage] = useState(1);
  const [formOpen, setFormOpen] = useState(false);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [invitesRefreshKey, setInvitesRefreshKey] = useState(0);
  const [editingUser, setEditingUser] = useState(null);
  const [deletingId, setDeletingId] = useState(null);
  const [searchParams, setSearchParams] = useSearchParams();

  // Lets the Topbar's "Create" shortcut (?invite=1) open this form directly.
  useEffect(() => {
    if (searchParams.get('invite') === '1') {
      setInviteOpen(true);
      setSearchParams((params) => {
        params.delete('invite');
        return params;
      }, { replace: true });
    }
  }, [searchParams, setSearchParams]);

  const { items, pagination, loading, refetch } = useList(
    '/users',
    'users',
    { search, role, page },
    [search, role, page]
  );

  function updateFilter(setter) {
    return (value) => {
      setter(value);
      setPage(1);
    };
  }

  function openCreate() {
    setEditingUser(null);
    setFormOpen(true);
  }

  function openEdit(u) {
    setEditingUser(u);
    setFormOpen(true);
  }

  async function handleDelete(u) {
    if (!window.confirm(`Delete ${u.name}'s account? This cannot be undone.`)) return;
    setDeletingId(u.id);
    try {
      await api.delete(`/users/${u.id}`);
      refetch();
    } catch (err) {
      window.alert(err.response?.data?.message || 'Could not delete this user.');
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <div>
      <PageHeader
        title="Users"
        description="Every account in the organization, and the role each one holds. New teammates join by invite."
        action={
          <div className="flex items-center gap-2">
            <Button variant="secondary" size="sm" onClick={openCreate}>
              <Plus className="h-4 w-4" /> Add directly
            </Button>
            <Button size="sm" onClick={() => setInviteOpen(true)}>
              <MailPlus className="h-4 w-4" /> Invite user
            </Button>
          </div>
        }
      />

      <Toolbar>
        <SearchField value={search} onChange={updateFilter(setSearch)} placeholder="Search users…" />
        <Select
          value={role}
          onChange={updateFilter(setRole)}
          placeholder="All roles"
          options={Object.entries(ROLE_LABELS).map(([value, label]) => ({ value, label }))}
        />
      </Toolbar>

      <Card>
        {loading ? (
          <div className="flex flex-col gap-px p-1">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-14 animate-pulse rounded bg-line/40" />
            ))}
          </div>
        ) : items.length === 0 ? (
          <EmptyState title="No users found" />
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs text-ink-muted">
                <th className="px-5 py-3 font-medium">Name</th>
                <th className="px-5 py-3 font-medium">Role</th>
                <th className="px-5 py-3 font-medium">Status</th>
                <th className="px-5 py-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {items.map((u) => (
                <tr key={u.id} className="hover:bg-paper">
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2.5">
                      <Avatar name={u.name} size="sm" />
                      <div>
                        <p className="font-medium text-ink">{u.name}</p>
                        <p className="text-xs text-ink-muted">{u.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-3 text-ink-soft">{ROLE_LABELS[u.role]}</td>
                  <td className="px-5 py-3">
                    <span
                      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                        u.isActive ? 'bg-success-50 text-success-600' : 'bg-ink-muted/10 text-ink-soft'
                      }`}
                    >
                      {u.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-5 py-3">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        type="button"
                        onClick={() => openEdit(u)}
                        className="rounded p-1.5 text-ink-muted hover:bg-paper hover:text-ink"
                        aria-label={`Edit ${u.name}`}
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </button>
                      {u.id !== currentUser.id && (
                        <button
                          type="button"
                          onClick={() => handleDelete(u)}
                          disabled={deletingId === u.id}
                          className="rounded p-1.5 text-ink-muted hover:bg-danger-50 hover:text-danger-600 disabled:opacity-50"
                          aria-label={`Delete ${u.name}`}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>

      <Pagination pagination={pagination} onPageChange={setPage} />

      <PendingInvites refreshKey={invitesRefreshKey} />

      <UserForm
        open={formOpen}
        onClose={() => setFormOpen(false)}
        onSaved={() => refetch()}
        user={editingUser}
      />

      <InviteForm
        open={inviteOpen}
        onClose={() => setInviteOpen(false)}
        onSent={() => setInvitesRefreshKey((k) => k + 1)}
      />
    </div>
  );
}
