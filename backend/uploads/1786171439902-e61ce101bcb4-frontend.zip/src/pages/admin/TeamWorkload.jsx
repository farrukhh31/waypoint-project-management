import { useEffect, useState } from 'react';
import api from '../../lib/api';
import Card, { CardHeader, CardBody } from '../../components/ui/Card.jsx';
import Avatar from '../../components/ui/Avatar.jsx';
import TiltCard from '../../components/ui/TiltCard.jsx';
import FullScreenLoader from '../../components/ui/FullScreenLoader.jsx';
import EmptyState from '../../components/ui/EmptyState.jsx';
import { TASK_STATUS_META } from '../../config/statuses';

// Groups every team member's assigned tasks into an open/in-progress/
// review/completed breakdown so an admin can spot who's overloaded at
// a glance — a load bar per person rather than a raw count table.
export default function TeamWorkload() {
  const [members, setMembers] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    Promise.all([
      api.get('/users', { params: { role: 'TEAM_MEMBER', limit: 100 } }),
      api.get('/tasks', { params: { limit: 100 } }),
    ]).then(([usersRes, tasksRes]) => {
      if (cancelled) return;
      setMembers(usersRes.data.data.users);
      setTasks(tasksRes.data.data.tasks);
      setLoading(false);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) return <FullScreenLoader />;

  const byMember = members.map((member) => {
    const assigned = tasks.filter((t) => t.assignee?.id === member.id);
    const counts = { TODO: 0, IN_PROGRESS: 0, REVIEW: 0, COMPLETED: 0 };
    assigned.forEach((t) => {
      counts[t.status] = (counts[t.status] || 0) + 1;
    });
    const active = assigned.length - counts.COMPLETED;
    return { member, assigned, counts, active };
  });

  const maxActive = Math.max(...byMember.map((m) => m.active), 1);

  return (
    <div className="flex flex-col gap-6">
      <Card>
        <CardHeader>
          <div>
            <h3 className="font-display text-base font-semibold text-ink">Team workload</h3>
            <p className="text-xs text-ink-muted">Active (non-completed) task load per team member</p>
          </div>
        </CardHeader>
        <CardBody>
          {byMember.length === 0 ? (
            <EmptyState title="No team members yet" description="Invite team members to see workload here." />
          ) : (
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {byMember
                .sort((a, b) => b.active - a.active)
                .map(({ member, counts, active }) => (
                  <TiltCard key={member.id} maxTilt={4} className="rounded-lg">
                    <Card className="h-full p-4 shadow-none">
                      <div className="mb-3 flex items-center gap-2.5">
                        <Avatar name={member.name} />
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium text-ink">{member.name}</p>
                          <p className="truncate text-xs text-ink-muted">{member.jobTitle || 'Team member'}</p>
                        </div>
                      </div>

                      <div className="mb-2 h-2 w-full overflow-hidden rounded-full bg-paper">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-route-400 to-route-600 transition-all"
                          style={{ width: `${(active / maxActive) * 100}%` }}
                        />
                      </div>
                      <p className="mb-3 text-xs text-ink-muted">{active} active task{active === 1 ? '' : 's'}</p>

                      <div className="flex flex-wrap gap-1.5">
                        {Object.entries(counts).map(([status, count]) =>
                          count > 0 ? (
                            <span
                              key={status}
                              className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${TASK_STATUS_META[status].className}`}
                            >
                              {count} {TASK_STATUS_META[status].label}
                            </span>
                          ) : null
                        )}
                      </div>
                    </Card>
                  </TiltCard>
                ))}
            </div>
          )}
        </CardBody>
      </Card>
    </div>
  );
}
