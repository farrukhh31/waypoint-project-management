import { useEffect, useRef, useState } from 'react';
import {
  Camera,
  Check,
  CheckCircle2,
  AlertCircle,
  Copy,
  Mail,
  ShieldCheck,
  CalendarDays,
  UserCog,
  BadgeCheck,
  Briefcase,
  X as XIcon,
} from 'lucide-react';
import api from '../../lib/api';
import { useAuth } from '../../hooks/useAuth';
import { ROLE_LABELS, ROLES } from '../../config/roles';
import Card, { CardBody } from '../../components/ui/Card.jsx';
import Avatar from '../../components/ui/Avatar.jsx';
import Input, { Field } from '../../components/ui/Input.jsx';
import PasswordInput from '../../components/ui/PasswordInput.jsx';
import Button from '../../components/ui/Button.jsx';
import StatCard from '../../components/ui/StatCard.jsx';
import { formatDate } from '../../utils/formatDate';

const ROLE_TONE = {
  [ROLES.ADMIN]: { accent: 'danger', badge: 'bg-danger-50 text-danger-600' },
  [ROLES.PROJECT_MANAGER]: { accent: 'route', badge: 'bg-route-100 text-route-700' },
  [ROLES.TEAM_MEMBER]: { accent: 'teal', badge: 'bg-teal-50 text-teal-700' },
};

// Small floating card anchored to the avatar for pasting a photo URL — kept
// as an inline popover rather than a full Modal so editing a photo feels
// like a one-click, in-place action instead of a context switch.
function AvatarEditPopover({ currentUrl, onClose, onSave, saving }) {
  const [url, setUrl] = useState(currentUrl || '');
  const ref = useRef(null);

  useEffect(() => {
    function onClickOutside(e) {
      if (ref.current && !ref.current.contains(e.target)) onClose();
    }
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, [onClose]);

  return (
    <div
      ref={ref}
      className="absolute left-1/2 top-full z-30 mt-3 w-72 -translate-x-1/2 rounded-xl border border-line bg-surface p-4 shadow-pop animate-[fade-in-up_0.15s_ease-out]"
    >
      <div className="mb-3 flex items-center justify-between">
        <p className="text-sm font-semibold text-ink">Update photo</p>
        <button
          type="button"
          onClick={onClose}
          className="rounded p-1 text-ink-muted hover:bg-paper hover:text-ink"
          aria-label="Close"
        >
          <XIcon className="h-3.5 w-3.5" />
        </button>
      </div>
      <div className="flex items-center gap-3">
        <Avatar name="Preview" src={url} size="md" />
        <Input
          autoFocus
          placeholder="Paste an image URL"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          className="h-9 text-sm"
        />
      </div>
      <p className="mt-2 text-xs text-ink-muted">Link to any image on the web — square photos look best.</p>
      <div className="mt-3 flex justify-end gap-2">
        {currentUrl && (
          <Button variant="ghost" size="sm" onClick={() => onSave('')} loading={saving}>
            Remove
          </Button>
        )}
        <Button size="sm" onClick={() => onSave(url)} loading={saving} disabled={url === (currentUrl || '')}>
          Save
        </Button>
      </div>
    </div>
  );
}

function InlineMessage({ message }) {
  if (!message) return null;
  const isError = message.type === 'error';
  return (
    <div
      className={
        'flex items-center gap-2 rounded-lg px-3 py-2 text-sm animate-[fade-in-up_0.15s_ease-out] ' +
        (isError ? 'bg-danger-50 text-danger-600' : 'bg-success-50 text-success-600')
      }
    >
      {isError ? <AlertCircle className="h-4 w-4 shrink-0" /> : <CheckCircle2 className="h-4 w-4 shrink-0" />}
      {message.text}
    </div>
  );
}

export default function Profile() {
  const { user, refreshMe } = useAuth();
  const tone = ROLE_TONE[user.role] || ROLE_TONE[ROLES.TEAM_MEMBER];

  const [tab, setTab] = useState('overview');

  const [name, setName] = useState(user.name);
  const [jobTitle, setJobTitle] = useState(user.jobTitle || '');
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileMessage, setProfileMessage] = useState(null);

  const [avatarPopoverOpen, setAvatarPopoverOpen] = useState(false);
  const [savingAvatar, setSavingAvatar] = useState(false);

  const [passwords, setPasswords] = useState({ currentPassword: '', newPassword: '' });
  const [savingPassword, setSavingPassword] = useState(false);
  const [passwordMessage, setPasswordMessage] = useState(null);

  const [emailCopied, setEmailCopied] = useState(false);

  async function handleProfileSubmit(e) {
    e.preventDefault();
    setSavingProfile(true);
    setProfileMessage(null);
    try {
      await api.patch('/users/me/profile', { name, jobTitle });
      await refreshMe();
      setProfileMessage({ type: 'success', text: 'Profile updated.' });
    } catch (err) {
      setProfileMessage({ type: 'error', text: err.response?.data?.message || 'Could not update profile.' });
    } finally {
      setSavingProfile(false);
    }
  }

  async function handleAvatarSave(url) {
    setSavingAvatar(true);
    try {
      await api.patch('/users/me/profile', { avatarUrl: url || undefined });
      await refreshMe();
      setAvatarPopoverOpen(false);
    } catch {
      // Popover stays open so the person can retry with a different URL.
    } finally {
      setSavingAvatar(false);
    }
  }

  async function handlePasswordSubmit(e) {
    e.preventDefault();
    setSavingPassword(true);
    setPasswordMessage(null);
    try {
      await api.patch('/users/me/password', passwords);
      setPasswords({ currentPassword: '', newPassword: '' });
      setPasswordMessage({ type: 'success', text: 'Password changed.' });
    } catch (err) {
      setPasswordMessage({ type: 'error', text: err.response?.data?.message || 'Could not change password.' });
    } finally {
      setSavingPassword(false);
    }
  }

  function copyEmail() {
    navigator.clipboard?.writeText(user.email).then(() => {
      setEmailCopied(true);
      setTimeout(() => setEmailCopied(false), 1600);
    });
  }

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-6">
      {/* Hero */}
      <Card className="overflow-visible">
        <div className="relative h-24 overflow-hidden rounded-t-lg bg-gradient-to-r from-route-600 via-route-500 to-accent-400">
          <div className="route-line absolute inset-x-0 bottom-0 h-px opacity-40" aria-hidden="true" />
          <div className="animate-glow-pulse absolute -right-6 -top-10 h-32 w-32 rounded-full bg-white/10 blur-2xl" aria-hidden="true" />
          <div className="absolute -left-8 bottom-[-40%] h-28 w-28 rounded-full bg-accent-200/20 blur-2xl" aria-hidden="true" />
        </div>

        <CardBody className="relative pt-0">
          <div className="relative -mt-10 flex flex-col items-start gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div className="flex items-end gap-4">
              <div className="relative">
                <Avatar
                  name={user.name}
                  src={user.avatarUrl}
                  size="lg"
                  className="h-20 w-20 text-xl ring-4 ring-surface shadow-pop"
                />
                <button
                  type="button"
                  onClick={() => setAvatarPopoverOpen((o) => !o)}
                  className="absolute -bottom-1 -right-1 flex h-7 w-7 items-center justify-center rounded-full bg-route-500 text-white shadow-pop ring-2 ring-surface transition-transform hover:scale-105 hover:bg-route-600"
                  aria-label="Change photo"
                >
                  <Camera className="h-3.5 w-3.5" />
                </button>
                {avatarPopoverOpen && (
                  <AvatarEditPopover
                    currentUrl={user.avatarUrl}
                    saving={savingAvatar}
                    onClose={() => setAvatarPopoverOpen(false)}
                    onSave={handleAvatarSave}
                  />
                )}
              </div>

              <div className="pb-1">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="font-display text-lg font-semibold text-ink">{user.name}</p>
                  <span className={'inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium ' + tone.badge}>
                    <BadgeCheck className="h-3 w-3" /> {ROLE_LABELS[user.role]}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={copyEmail}
                  className="group mt-1 flex items-center gap-1.5 text-sm text-ink-muted hover:text-route-600"
                >
                  <Mail className="h-3.5 w-3.5" />
                  {user.email}
                  {emailCopied ? (
                    <Check className="h-3 w-3 text-success-500" />
                  ) : (
                    <Copy className="h-3 w-3 opacity-0 transition-opacity group-hover:opacity-100" />
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Quick stats */}
          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
            <StatCard label="Role" value={ROLE_LABELS[user.role]} icon={ShieldCheck} accent={tone.accent} />
            <StatCard label="Member since" value={formatDate(user.createdAt)} icon={CalendarDays} accent="sky" />
            {user.role === ROLES.PROJECT_MANAGER ? (
              <StatCard
                label="Invite permission"
                value={user.canInviteMembers ? 'Granted' : 'Not granted'}
                icon={UserCog}
                accent={user.canInviteMembers ? 'success' : 'accent'}
              />
            ) : (
              <StatCard
                label="Account status"
                value={user.isActive ? 'Active' : 'Inactive'}
                icon={UserCog}
                accent={user.isActive ? 'success' : 'danger'}
              />
            )}
          </div>
        </CardBody>
      </Card>

      {/* Tabs */}
      <div className="flex w-fit gap-1 rounded-full border border-line bg-surface p-1 shadow-card">
        {[
          { id: 'overview', label: 'Overview' },
          { id: 'security', label: 'Security' },
        ].map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={
              'rounded-full px-4 py-1.5 text-sm font-medium transition-colors ' +
              (tab === t.id ? 'bg-route-500 text-white shadow-sm' : 'text-ink-soft hover:bg-paper')
            }
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'overview' && (
        <Card className="card-sheen animate-[fade-in-up_0.2s_ease-out]">
          <CardBody>
            <div className="mb-4 flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-route-100 text-route-600">
                <UserCog className="h-4.5 w-4.5" />
              </div>
              <div>
                <h3 className="font-display text-base font-semibold text-ink">Edit profile</h3>
                <p className="text-xs text-ink-muted">Your name and role appear across every project you're on.</p>
              </div>
            </div>
            <form onSubmit={handleProfileSubmit} className="flex flex-col gap-4">
              <Field label="Full name" htmlFor="name">
                <Input id="name" value={name} onChange={(e) => setName(e.target.value)} />
              </Field>
              <Field label="Job title" htmlFor="jobTitle">
                <Input
                  id="jobTitle"
                  icon={Briefcase}
                  placeholder="e.g. Senior Product Designer"
                  value={jobTitle}
                  onChange={(e) => setJobTitle(e.target.value)}
                />
              </Field>
              <InlineMessage message={profileMessage} />
              <Button type="submit" className="w-fit" loading={savingProfile}>
                Save changes
              </Button>
            </form>
          </CardBody>
        </Card>
      )}

      {tab === 'security' && (
        <Card className="card-sheen animate-[fade-in-up_0.2s_ease-out]">
          <CardBody>
            <div className="mb-4 flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-danger-50 text-danger-600">
                <ShieldCheck className="h-4.5 w-4.5" />
              </div>
              <div>
                <h3 className="font-display text-base font-semibold text-ink">Change password</h3>
                <p className="text-xs text-ink-muted">Use something you don't use anywhere else.</p>
              </div>
            </div>
            <form onSubmit={handlePasswordSubmit} className="flex flex-col gap-4">
              <Field label="Current password" htmlFor="currentPassword">
                <PasswordInput
                  autoComplete="current-password"
                  required
                  value={passwords.currentPassword}
                  onChange={(e) => setPasswords({ ...passwords, currentPassword: e.target.value })}
                />
              </Field>
              <Field label="New password" htmlFor="newPassword">
                <PasswordInput
                  autoComplete="new-password"
                  required
                  minLength={8}
                  showStrength
                  value={passwords.newPassword}
                  onChange={(e) => setPasswords({ ...passwords, newPassword: e.target.value })}
                />
              </Field>
              <InlineMessage message={passwordMessage} />
              <Button type="submit" className="w-fit" loading={savingPassword}>
                Update password
              </Button>
            </form>
          </CardBody>
        </Card>
      )}
    </div>
  );
}
