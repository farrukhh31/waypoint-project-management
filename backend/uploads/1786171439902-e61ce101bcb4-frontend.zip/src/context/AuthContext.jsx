import { createContext, useCallback, useEffect, useState } from 'react';
import api, { setAccessToken, setUnauthorizedHandler } from '../lib/api';
import { connectSocket, disconnectSocket } from '../lib/socket';

export const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [status, setStatus] = useState('loading'); // 'loading' | 'authenticated' | 'guest'

  const clearSession = useCallback(() => {
    setAccessToken(null);
    disconnectSocket();
    setUser(null);
    setStatus('guest');
  }, []);

  // On first load there's no access token in memory yet, but the httpOnly
  // refresh cookie may still be valid — try it once so a page refresh
  // doesn't bounce an already-logged-in user back to /login.
  useEffect(() => {
    setUnauthorizedHandler(clearSession);

    (async () => {
      try {
        const { data } = await api.post('/auth/refresh');
        setAccessToken(data.data.accessToken);
        const me = await api.get('/auth/me');
        setUser(me.data.data.user);
        setStatus('authenticated');
        connectSocket();
      } catch {
        setStatus('guest');
      }
    })();
  }, [clearSession]);

  const login = useCallback(async (email, password) => {
    const { data } = await api.post('/auth/login', { email, password });
    setAccessToken(data.data.accessToken);
    setUser(data.data.user);
    setStatus('authenticated');
    connectSocket();
    return data.data.user;
  }, []);

  const logout = useCallback(async () => {
    try {
      await api.post('/auth/logout');
    } finally {
      clearSession();
    }
  }, [clearSession]);

  const refreshMe = useCallback(async () => {
    const { data } = await api.get('/auth/me');
    setUser(data.data.user);
    return data.data.user;
  }, []);

  return (
    <AuthContext.Provider value={{ user, status, login, logout, refreshMe }}>
      {children}
    </AuthContext.Provider>
  );
}
